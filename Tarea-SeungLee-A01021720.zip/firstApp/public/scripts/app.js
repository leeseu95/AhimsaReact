"use strict";

console.log("It works!");

var numero = 234;
var gasStation = {
    name: "Gas Interlomas",
    brand: "Shell",
    price: 19.00,
    comments: []
};

var counter = 0;

var showPrice = function showPrice() {
    if (!gasStation.price) return undefined;else return React.createElement(
        "p",
        null,
        "Price: ",
        gasStation.price
    );
};

var addOne = function addOne() {
    console.log("add one");
    counter++;
    render();
    if (counter == 10) counter = 0;
};

var onFormSubmit = function onFormSubmit(e) {
    e.preventDefault();
    var comment = e.target.elements.comment.value;
    if (comment) {
        gasStation.comments.push(comment);
        e.target.elements.comment.value = '';
        render();
    }
};

var numbers = [123, 23, 45];

var randomComment = function randomComment() {
    var randomNum = Math.floor(Math.random() * gasStation.comments.length);
    var option = gasStation.comments[randomNum];
    alert(option);
};

var render = function render() {
    var template = React.createElement(
        "div",
        null,
        React.createElement(
            "h3",
            null,
            gasStation.name
        ),
        React.createElement(
            "ul",
            null,
            gasStation.brand && gasStation.brand == "Shell" && React.createElement(
                "li",
                null,
                "Brand: ",
                gasStation.brand
            )
        ),
        showPrice(),
        React.createElement(
            "p",
            null,
            "Counter: ",
            counter
        ),
        React.createElement(
            "button",
            { className: "myClass", onClick: addOne },
            "Increment"
        ),
        React.createElement(
            "p",
            null,
            gasStation.comments.length > 0 ? 'Comentarios: ' : 'Sin comentarios'
        ),
        gasStation.comments && gasStation.comments.length > 0 && React.createElement(
            "ol",
            null,
            gasStation.comments.map(function (comment) {
                return React.createElement(
                    "li",
                    { key: counter++ },
                    comment
                );
            })
        ),
        React.createElement(
            "form",
            { onSubmit: onFormSubmit },
            React.createElement("input", { type: "text", name: "comment" }),
            React.createElement(
                "button",
                null,
                "Agregar comentario"
            )
        ),
        React.createElement(
            "button",
            { disabled: gasStation.comments.length == 0, onClick: randomComment },
            "Random Comment"
        )
    );
    ReactDOM.render(template, appRoot);
};

var appRoot = document.getElementById('app');

render();
